package DesignPatterns.Behavioral.Observer;

public class Goblin implements Observer {

    @Override
    public void response() {}
}
